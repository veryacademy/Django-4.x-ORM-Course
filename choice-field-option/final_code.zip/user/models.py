from django.db import models

class Person(models.Model):

    class Colours(models.TextChoices):
        RED = 'RD', 'Red'
        BLUE = 'BL', 'Blue'

    name = models.CharField(max_length=50)
    colour = models.CharField(max_length=50, choices=Colours.choices)